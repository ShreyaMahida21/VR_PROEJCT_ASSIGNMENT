// ProductsList.js
import React, { useState } from 'react';
import VirtualTryOn from './VirtualTryOn';

const images = require.context('./assets/images', false, /\.(png|jpe?g|svg)$/);

const imageList = images.keys().map((key, index) => ({
  name: key.replace('./', ''),
  src: images(key),
  brand: ['Ray-Ban', 'Oakley', 'Gucci'][index % 3],
  price: [1999, 2499, 3299][index % 3],
  material: ['Titanium', 'Plastic', 'Metal'][index % 3],
}));

const ProductsList = () => {
  const [activeIndex, setActiveIndex] = useState(null);
  const [selectedColor, setSelectedColor] = useState('#ffffff');
  const [showInfo, setShowInfo] = useState(false);

  const toggleComponent = (index) => {
    if (activeIndex === index) {
      setActiveIndex(null);
      setShowInfo(false);
    } else {
      setActiveIndex(index);
      setSelectedColor('#ffffff');
      setShowInfo(false);
    }
  };

  const handleTryOnClick = () => {
    setShowInfo(true);
  };

  return (
    <>
      <div style={{ borderBottom: '1px solid rgba(0, 0, 0, 0.2)' }}>
        <h1 style={{ textAlign: 'center', padding: '10px 0' }}>Virtual Try-On - Smart Specs</h1>
      </div>

      {activeIndex !== null && (
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '30px' }}>
          <VirtualTryOn
            uri={imageList[activeIndex].src}
            productInfo={{
              brand: imageList[activeIndex].brand,
              price: imageList[activeIndex].price,
              material: imageList[activeIndex].material,
            }}
            selectedColor={selectedColor}
            onColorChange={setSelectedColor}
            onGlassesClick={handleTryOnClick}
            showInfo={showInfo}
          />
        </div>
      )}

      <div
        className="containerAll"
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: '20px',
          padding: '30px 0',
        }}
      >
        {imageList.map((image, index) => (
          <div
            className="container"
            key={index}
            style={{
              textAlign: 'center',
              border: '1px solid #ddd',
              borderRadius: '10px',
              padding: '10px',
              width: '200px',
              boxShadow: '0px 2px 8px rgba(0,0,0,0.1)',
            }}
          >
            <img
              src={image.src}
              alt={image.name}
              style={{
                width: '100%',
                height: '140px',
                objectFit: 'contain',
                marginBottom: '10px',
              }}
            />
            <button
              onClick={() => toggleComponent(index)}
              style={{
                padding: '8px 16px',
                borderRadius: '5px',
                border: 'none',
                backgroundColor: activeIndex === index ? '#f44336' : '#4CAF50',
                color: 'white',
                cursor: 'pointer',
              }}
            >
              {activeIndex === index ? 'Close' : 'Try On'}
            </button>
          </div>
        ))}
      </div>
    </>
  );
};

export default ProductsList;
